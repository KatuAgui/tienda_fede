import { connectDB } from "../config/database";
import { Categoria } from "../models/categoria.model";

export class CategoriaService {
  // Obtener todas las categorías
  async listarCategorias(): Promise<Categoria[]> {
    const connection = await connectDB();
    const [rows] = await connection.execute("SELECT * FROM categorias");
    return rows as Categoria[];
  }

  // Agregar nueva categoría
  async agregarCategoria(nombreCategoria: string): Promise<void> {
    const connection = await connectDB();
    await connection.execute("INSERT INTO categorias (nombreCategoria) VALUES (?)", [nombreCategoria]);
  }

  // Eliminar categoría por id
  async eliminarCategoria(idCategoria: number): Promise<void> {
    const connection = await connectDB();
    await connection.execute("DELETE FROM categorias WHERE idCategoria = ?", [idCategoria]);
  }
}
